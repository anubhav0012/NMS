## Introduction:
This is a NGO Managment Site (NMS) of a organistion which takes donation from the donors and runs a School. 
There ar three type of members in the Site
1. Maanger
2. Staff
3. Donor

## Languages used:
FLask Framnework of Python is used for backend purpose.
HTML and CSS for Web pages
MySQL for the database


(The database details are been commented and the database had ben turned off) 
You have to create your own database and can execute it.

## Environment

Run pip install -r requirements.txt

## Contact
 For any queries, feel free to contact me at [mannanbaidi@gmail.com] or on [https://www.instagram.com/bady_mannan/]
